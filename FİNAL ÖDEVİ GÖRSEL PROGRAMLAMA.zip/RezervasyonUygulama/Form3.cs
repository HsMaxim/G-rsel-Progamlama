﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace RezervasyonUygulama
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private string connectionString = "Server=localhost;Database=rezervasyon_db;Uid=root;Pwd=;";

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string kullanici = txtKullanici.Text.Trim();
            string sifre = txtSifre.Text.Trim();

            if (string.IsNullOrEmpty(kullanici) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifre giriniz.");
                return;
            }

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM adminler WHERE kullanici = @kul AND sifre = @sif";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@kul", kullanici);
                cmd.Parameters.AddWithValue("@sif", sifre);

                int sonuc = Convert.ToInt32(cmd.ExecuteScalar());
                if (sonuc > 0)
                {
                    this.Hide();
                    Form1 form = new Form1();
                    form.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Hatalı giriş! Lütfen tekrar deneyiniz.");
                }
            }
        }
    }
}
