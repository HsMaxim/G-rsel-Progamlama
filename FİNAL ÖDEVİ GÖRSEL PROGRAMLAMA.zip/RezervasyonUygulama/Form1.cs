﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace RezervasyonUygulama
{
    public partial class Form1 : Form
    {
        private Dictionary<string, int> masaKapasiteleri = new Dictionary<string, int>();
        private string connectionString = "Server=localhost;Database=rezervasyon_db;Uid=root;Pwd=;";

        public Form1()
        {
            InitializeComponent();
        }

        public void SetDuzenlemeSatiri(string satir)
        {
            var veriler = satir.Split('|').Select(x => x.Trim()).ToArray();
            if (veriler.Length != 7) return;

            txtAdSoyad.Text = veriler[0];
            txtTelefon.Text = veriler[1];
            dtTarih.Value = DateTime.Parse(veriler[2]);
            cmbSaat.SelectedItem = veriler[3].Replace("Saat: ", "");
            cmbMasa.SelectedItem = veriler[4].Replace("Masa: ", "");
            nudKisi.Value = int.Parse(veriler[5].Replace("Kişi: ", ""));
            cmbSube.SelectedItem = veriler[6].Replace("Şube: ", "");

            MasalariYukle();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbSaat.Items.AddRange(new object[] { "12:00", "13:00", "14:00", "15:00", "18:00", "19:00", "20:00" });
            cmbSube.Items.AddRange(new object[] { "Kadıköy", "Üsküdar", "Beşiktaş" });
            cmbSaat.SelectedIndex = 0;
            cmbSube.SelectedIndex = 0;
            dtTarih.Value = DateTime.Today;
            MasalariYukle();
        }

        private void MasalariYukle()
        {
            flpMasalar.Controls.Clear();
            cmbMasa.Items.Clear();
            masaKapasiteleri.Clear();

            string tarih = dtTarih.Value.ToString("yyyy-MM-dd");
            string saat = cmbSaat.SelectedItem?.ToString();
            string sube = cmbSube.SelectedItem?.ToString();

            List<(string masa, int kapasite)> masalar = new List<(string, int)>();

            if (sube == "Kadıköy")
                masalar.AddRange(new[] { ("Masa 1", 2), ("Masa 2", 4), ("Masa 3", 6) });
            else if (sube == "Üsküdar")
                masalar.AddRange(new[] { ("Masa 1", 4), ("Masa 2", 4), ("Masa 3", 6), ("Masa 4", 2) });
            else if (sube == "Beşiktaş")
                masalar.AddRange(new[] { ("Masa 1", 6), ("Masa 2", 4), ("Masa 3", 2) });

            foreach (var (masa, kapasite) in masalar)
            {
                var btn = new Button
                {
                    Text = $"{masa}\n({kapasite} kişilik)",
                    Width = 100,
                    Height = 50,
                    Tag = masa,
                    BackColor = MasaDoluMu(masa, tarih, saat, sube) ? Color.Red : Color.Green,
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat
                };
                btn.Click += MasaSec;
                masaKapasiteleri[masa] = kapasite;
                cmbMasa.Items.Add(masa);
                flpMasalar.Controls.Add(btn);
            }
        }

        private bool MasaDoluMu(string masa, string tarih, string saat, string sube)
        {
            string masaNo = new string(masa.Where(char.IsDigit).ToArray());

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM rezervasyonlar WHERE tarih = @tarih AND saat = @saat AND masa_no = @masa AND sube = @sube";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@tarih", tarih);
                cmd.Parameters.AddWithValue("@saat", saat);
                cmd.Parameters.AddWithValue("@masa", masaNo);
                cmd.Parameters.AddWithValue("@sube", sube);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }

        private void MasaSec(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            if (btn.BackColor == Color.Red)
            {
                MessageBox.Show("Bu masa dolu!");
                return;
            }
            cmbMasa.SelectedItem = btn.Tag.ToString();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            string ad = txtAdSoyad.Text.Trim();
            string tel = txtTelefon.Text.Trim();
            string tarih = dtTarih.Value.ToString("yyyy-MM-dd");
            string saat = cmbSaat.SelectedItem?.ToString();
            string masa = cmbMasa.SelectedItem?.ToString();
            string sube = cmbSube.SelectedItem?.ToString();
            int kisi = (int)nudKisi.Value;

            if (string.IsNullOrEmpty(ad) || string.IsNullOrEmpty(tel) || string.IsNullOrEmpty(masa))
            {
                MessageBox.Show("Tüm alanları doldurun.");
                return;
            }

            if (masaKapasiteleri.ContainsKey(masa) && kisi > masaKapasiteleri[masa])
            {
                MessageBox.Show($"Bu masa en fazla {masaKapasiteleri[masa]} kişiliktir.");
                return;
            }

            if (MasaDoluMu(masa, tarih, saat, sube))
            {
                MessageBox.Show("Bu masa dolu!");
                return;
            }

            string masaNo = new string(masa.Where(char.IsDigit).ToArray());

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO rezervasyonlar (adsoyad, telefon, tarih, saat, masa_no, kisi_sayisi, sube) VALUES (@ad, @tel, @tarih, @saat, @masa, @kisi, @sube)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ad", ad);
                cmd.Parameters.AddWithValue("@tel", tel);
                cmd.Parameters.AddWithValue("@tarih", tarih);
                cmd.Parameters.AddWithValue("@saat", saat);
                cmd.Parameters.AddWithValue("@masa", masaNo);
                cmd.Parameters.AddWithValue("@kisi", kisi);
                cmd.Parameters.AddWithValue("@sube", sube);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Rezervasyon başarıyla kaydedildi.");
            MasalariYukle();
        }

        private void cmbSaat_SelectedIndexChanged(object sender, EventArgs e) => MasalariYukle();
        private void dtTarih_ValueChanged(object sender, EventArgs e) => MasalariYukle();
        private void cmbSube_SelectedIndexChanged(object sender, EventArgs e) => MasalariYukle();

        private void btnListele_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();
        }
    }
}
