﻿namespace RezervasyonUygulama
{
    partial class Form3
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtKullanici;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.Label lblKullanici;
        private System.Windows.Forms.Label lblSifre;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtKullanici = new System.Windows.Forms.TextBox();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.lblKullanici = new System.Windows.Forms.Label();
            this.lblSifre = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // Label Kullanıcı
            this.lblKullanici.Text = "Kullanıcı Adı:";
            this.lblKullanici.Font = new System.Drawing.Font("Segoe UI", 10);
            this.lblKullanici.Location = new System.Drawing.Point(30, 30);
            this.lblKullanici.Size = new System.Drawing.Size(120, 25);

            // TextBox Kullanıcı
            this.txtKullanici.Location = new System.Drawing.Point(160, 30);
            this.txtKullanici.Size = new System.Drawing.Size(200, 25);
            this.txtKullanici.Font = new System.Drawing.Font("Segoe UI", 10);

            // Label Şifre
            this.lblSifre.Text = "Şifre:";
            this.lblSifre.Font = new System.Drawing.Font("Segoe UI", 10);
            this.lblSifre.Location = new System.Drawing.Point(30, 80);
            this.lblSifre.Size = new System.Drawing.Size(120, 25);

            // TextBox Şifre
            this.txtSifre.Location = new System.Drawing.Point(160, 80);
            this.txtSifre.Size = new System.Drawing.Size(200, 25);
            this.txtSifre.Font = new System.Drawing.Font("Segoe UI", 10);
            this.txtSifre.PasswordChar = '*';

            // Giriş Butonu
            this.btnGiris.Text = "Giriş Yap";
            this.btnGiris.Location = new System.Drawing.Point(160, 130);
            this.btnGiris.Size = new System.Drawing.Size(200, 35);
            this.btnGiris.Font = new System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold);
            this.btnGiris.BackColor = System.Drawing.Color.FromArgb(183, 28, 28);
            this.btnGiris.ForeColor = System.Drawing.Color.White;
            this.btnGiris.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);

            // Form3 Ayarları
            this.ClientSize = new System.Drawing.Size(400, 200);
            this.Controls.Add(this.lblKullanici);
            this.Controls.Add(this.txtKullanici);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.btnGiris);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Name = "Form3";
            this.Text = "Admin Girişi";

            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
