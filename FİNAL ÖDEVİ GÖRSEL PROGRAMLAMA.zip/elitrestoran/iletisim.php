<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$baglanti = new mysqli("localhost", "root", "", "rezervasyon_db");
$baglanti->set_charset("utf8");

if ($baglanti->connect_error) {
    echo "error";
    exit;
}

$ad = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$mesaj = $_POST['message'] ?? '';

if (!$ad || !$email || !$mesaj) {
    echo "error";
    exit;
}

$sql = "INSERT INTO iletisimler (adsoyad, email, mesaj) VALUES (?, ?, ?)";
$stmt = $baglanti->prepare($sql);

if (!$stmt) {
    echo "error";
    exit;
}

$stmt->bind_param("sss", $ad, $email, $mesaj);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}

$stmt->close();
$baglanti->close();
?>
